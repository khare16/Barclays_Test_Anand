﻿
//***********************************************************************************************************************
//Scenario 1.Takes in two arguments (argument 1 = functionality to perform, argument 2 = filename)
//Scenario 2.If the second argument is anyone of –s, --s, /s, --size the return the size of the file (use FileDetails.Size)

//Note : point 1 and 2 is bit contradictory. In point 1 its mentioned argument 2 should be the fileName and in second point its mentioned second argument should be -s,--ss etc.
//I have written a logic to consider like first argument will take default values ( -v,--v,-s,--s) and second argument will take filename
//*****************************************************************************************************************************8

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThirdPartyTools;
namespace FileData
{
    public class FileInfoClass
    {
        /// <summary>
        /// GetFileData function will check the valid argument and according to the argument fuction will return fileVersion or FileSize
        /// </summary>
        /// <param name="argument"></param>
        /// <param name="filepath"></param>
        /// <returns></returns>
        private static readonly string[] VersionChoices = { "-v", "--v", "/v", "--version" };
        private static readonly string[] SizeChoices = { "-s", "--s", "/s", "--size" };
        public static string GetFileData(string argument, string filepath)
        {
            FileDetails fileDetails = new FileDetails();
            string retValue = string.Empty;
            try
            {
                if (VersionChoices.Contains(argument))
                    retValue = fileDetails.Version(filepath);
                else if (SizeChoices.Contains(argument))
                    retValue = fileDetails.Size(filepath).ToString();
                else
                    Console.WriteLine("Invlid Argument");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return retValue;
        }
    }
}