﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace FileData
{
    public static class Program
    {
        public static void Main(string[] args)
        {
          Console.WriteLine(FileInfoClass.GetFileData(args[0], args[1]));
          Console.ReadLine();
        }
    }
}
