﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FileData;
namespace FileDataTest
{
    [TestClass]
    public class FileDataTest
    {
        [TestMethod]
        public void FileDataTestSucess()
        {
            //Arrange 
                 string actual = string.Empty;
                 string argument="-v";
                 string filePath="c:\test.txt";
            
            ////Act  
                ShimFileDetails.Constructor = (X) => { new ShimFileDetails(); }; 
            //     actual = CFileData.GetFileData(argument,filePath);
            ////Assert  
               
            //Assert.AreEqual(expected, actual);  

            
        }
        [TestMethod]
        public void FileDataTestFailure()
        {

        }

    }
}
