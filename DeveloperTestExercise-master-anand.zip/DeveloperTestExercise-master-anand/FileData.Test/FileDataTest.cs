﻿using System;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FileData.Test
{
    /// <summary>
    /// GetFileData function returns random number not any fix number so for validation only I can check that function return a value or not.
    /// </summary>
    [TestClass]
    public class FileDataTest
    {
        private static readonly string[] VersionChoices = { "-v", "--v", "/v", "--version", "-s", "--s", "/s", "--size" };
        [TestMethod]
        public void FileData_RandomNumber_Validate()
        {
            string filePath="c:\\test.txt";
            Assert.AreEqual(ValidateFileData("-v", filePath), true);
            Assert.AreEqual(ValidateFileData("--v", filePath), true);
            Assert.AreEqual(ValidateFileData("/v", filePath), true);
            Assert.AreEqual(ValidateFileData("--version", filePath), true);
            Assert.AreEqual(ValidateFileData("-s", filePath), true);
            Assert.AreEqual(ValidateFileData("--s", filePath), true);
            Assert.AreEqual(ValidateFileData("/s", filePath), true);
            Assert.AreEqual(ValidateFileData("--size", filePath), true);
            Assert.AreEqual(ValidateFileData("-A", filePath), false);
         } 
        /// <summary>
        /// ValidateFileData function will return true incase of valid values otherwise it will return false value.
        /// </summary>
        /// <param name="argument"></param>
        /// <param name="filePath"></param>
        /// <returns></returns>
        static bool ValidateFileData (string argument,string filePath)
        {
            bool result;
            if (VersionChoices.Contains(argument))
            {
               result=true;
            }
            else
            {
               result=false;
            }
            return result;
        }
    }
}
